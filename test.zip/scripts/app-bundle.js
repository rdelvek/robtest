var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
define('app',["require", "exports", "aurelia-framework", "aurelia-templating-resources", "dragula", "aurelia-fetch-client"], function (require, exports, aurelia_framework_1, aurelia_templating_resources_1, dragula, aurelia_fetch_client_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var App = (function () {
        function App(signaler) {
            var _this = this;
            this.message = 'Hello World!';
            this.tester = [];
            this.httpClient = new aurelia_fetch_client_1.HttpClient();
            this.signaler = signaler;
            this.options = {
                sort: true,
                handle: '.my-handle',
                onSort: function (e) {
                    console.log(_this.tester);
                }
            };
        }
        App.prototype.attached = function () {
            var _this = this;
            console.log(this.tester);
            console.log(dragula);
            this.httpClient.fetch('http://localhost:3000/items')
                .then(function (response) { return response.json(); })
                .then(function (data) {
                _this.tester = data;
            });
        };
        App.prototype.doSignal = function () {
            this.signaler.signal('blao');
        };
        App.prototype.dragStart = function (e) {
            console.log(e);
        };
        App.prototype.func = function (customEvent) {
            var event = customEvent.detail;
            console.log("old index:", event.oldIndex);
            console.log("new index:", event.newIndex);
            this.signaler.signal('blao');
        };
        App.prototype.trackDrop = function (dragApi) {
            dragApi.on('drop', function (el, container, source) {
                var card = source.parentElement.card.card, pile = container.parentElement.parentElement.pile.pile;
                dragApi.cancel();
            });
        };
        App.prototype.trackDraggingState = function (dragApi) {
            var handle;
            dragApi.on('drag', function () {
            });
            dragApi.on('dragend', function () {
                clearTimeout(handle);
            });
        };
        return App;
    }());
    App = __decorate([
        aurelia_framework_1.inject(aurelia_templating_resources_1.BindingSignaler),
        __metadata("design:paramtypes", [aurelia_templating_resources_1.BindingSignaler])
    ], App);
    exports.App = App;
});

define('environment',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.default = {
        debug: true,
        testing: true
    };
});

define('main',["require", "exports", "./environment"], function (require, exports, environment_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function configure(aurelia) {
        aurelia.use
            .standardConfiguration()
            .feature('resources');
        if (environment_1.default.debug) {
            aurelia.use.developmentLogging();
        }
        if (environment_1.default.testing) {
            aurelia.use.plugin('aurelia-testing');
        }
        aurelia.start().then(function () { return aurelia.setRoot(); });
    }
    exports.configure = configure;
});

define('resources/index',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function configure(config) {
    }
    exports.configure = configure;
});

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
define('resources/attributes/sortable',["require", "exports", "aurelia-framework", "sortablejs"], function (require, exports, aurelia_framework_1, Sortable) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var SortableCustomAttribute = (function () {
        function SortableCustomAttribute(element) {
            this.element = element;
        }
        SortableCustomAttribute.prototype.detached = function () {
            this.sortable.destroy();
        };
        SortableCustomAttribute.prototype.attached = function () {
            if (!this.sortable) {
                this.sortable = Sortable.create(this.element, {});
            }
        };
        SortableCustomAttribute.prototype.valueChanged = function (newValue) {
            if (this.sortable) {
                this.sortable.destroy();
            }
            this.sortable = Sortable.create(this.element, Object.assign({}, newValue || {}));
            this.attachListeners();
        };
        SortableCustomAttribute.prototype.attachListeners = function () {
            var _this = this;
            Sortable.utils.on(this.element, "add", function (event) { return _this.dispatch("sortable-add", event); });
            Sortable.utils.on(this.element, "end", function (event) { return _this.dispatch("sortable-end", event); });
            Sortable.utils.on(this.element, "filter", function (event) { return _this.dispatch("sortable-filter", event); });
            Sortable.utils.on(this.element, "move", function (event) { return _this.dispatch("sortable-move", event); });
            Sortable.utils.on(this.element, "remove", function (event) { return _this.dispatch("sortable-remove", event); });
            Sortable.utils.on(this.element, "sort", function (event) { return _this.dispatch("sortable-sort", event); });
            Sortable.utils.on(this.element, "start", function (event) { return _this.dispatch("sortable-start", event); });
            Sortable.utils.on(this.element, "update", function (event) { return _this.dispatch("sortable-update", event); });
        };
        SortableCustomAttribute.prototype.dispatch = function (name, data) {
            this.element.dispatchEvent(new CustomEvent(name, {
                bubbles: true,
                detail: data,
            }));
        };
        return SortableCustomAttribute;
    }());
    SortableCustomAttribute = __decorate([
        aurelia_framework_1.inject(Element),
        __metadata("design:paramtypes", [Element])
    ], SortableCustomAttribute);
    exports.SortableCustomAttribute = SortableCustomAttribute;
});

define('resources/value-converters/sort',["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    var SortValueConverter = (function () {
        function SortValueConverter() {
        }
        SortValueConverter.prototype.toView = function (array, propertyName, direction) {
            var factor = direction === 'ascending' ? 1 : -1;
            return array
                .slice(0)
                .sort(function (a, b) {
                return (a[propertyName] - b[propertyName]) * factor;
            });
        };
        return SortValueConverter;
    }());
    exports.SortValueConverter = SortValueConverter;
});

define('text!app.html', ['module'], function(module) { module.exports = "<template><h1>${message}</h1><require from=\"./resources/value-converters/sort\"></require><button click.delegate=\"doSignal()\">Do Signal</button><ul><li repeat.for=\"item of tester | sort:'sortOrder':'ascending' & signal:'blao'\" draggable=\"true\" dragstart.delegate=\"dragStart($event)\"><span class=\"my-handle\" style=\"cursor:pointer\">[HANDLE]</span> ${item.name} - ${item.sortOrder}</li></ul></template>"; });
//# sourceMappingURL=app-bundle.js.map