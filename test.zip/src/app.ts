import {inject} from 'aurelia-framework';
import {BindingSignaler} from 'aurelia-templating-resources';
import * as dragula from 'dragula';

import {HttpClient} from 'aurelia-fetch-client';


@inject(BindingSignaler)

export class App {

  signaler;

  httpClient;

  message = 'Hello World!';

  tester = [];

  options:{};

  constructor(signaler:BindingSignaler){

    this.httpClient = new HttpClient();



    this.signaler = signaler;

    this.options ={
      sort: true,
      handle: '.my-handle',
      onSort: e => {

        console.log(this.tester);

            //e.item.remove();

        // Clone container
        // var clone = _a.clone(self._scope.model[self._scope.$key])
        // self._scope.model[self._scope.$key] = []

        // // Move to new position
        // var swappedEl = clone.splice(e.oldIndex, 1)[0]
        // clone.splice(e.newIndex, 0, swappedEl)

        // // On next Tick update with clone
        // self._scope.$nextTick(function() {
        //     self._scope.model[self._scope.$key] = clone
        // })
          // evt.preventDefault();
          //   return false;
        //var itemEl = evt.item;  // dragged HTMLElement
        // + indexes from onEnd


      }
    }
    
  }

  attached(){
   // var sortable = new Sortable.create(this.sortableitem, {});
   console.log(this.tester);

   console.log(dragula);

    this.httpClient.fetch('http://localhost:3000/items')
      .then(response => response.json())
        .then(data => {
          this.tester = data;
        });

    // this.httpClient.fetch('http://localhost:3000/items', {
    //   method: 'DELETE',
    //   headers: {
    //     'Content-Type': 'application/json'
    //   },
    //   body: JSON.stringify({
    //     name: 'Test1'
    //   })
    // });

  //  return Promise.resolve();

  //  let dragApi = dragula({
	// 		isContainer: el => {
	// 			if (!el) {
	// 				return false;
	// 			}
	// 			if (dragApi.dragging) {
	// 				return el.classList.contains('drop-target');
	// 			}
	// 			return el.classList.contains('drag-source');
	// 		},
	// 		revertOnSpill: true,
	// 		delay: 200
	// 	});

  //    console.log(dragApi);
     
	// 	this.trackDrop(dragApi);
	// 	this.trackDraggingState(dragApi);
  }

  doSignal(){
        this.signaler.signal('blao');
  }

  dragStart(e){
    console.log(e);
  }

  public func(customEvent: CustomEvent) {
    // customEvent.preventDefault();

    let event = customEvent.detail;
    //console.log("event", event);

    console.log("old index:", event.oldIndex);
    console.log("new index:", event.newIndex);

    this.signaler.signal('blao');
  }

  	trackDrop(dragApi) {
		dragApi.on('drop', (el, container, source) => {
			let card = source.parentElement.card.card,
				pile = container.parentElement.parentElement.pile.pile;
			dragApi.cancel();
			//this.eventAggregator.publish(new CardDroppedEvent(card, pile));
		});
	}

	trackDraggingState(dragApi) {
		let handle;
		dragApi.on('drag', () => {
			//handle = setTimeout(() => this.dragging = true, doubleClickDelay + 20);
		});
		dragApi.on('dragend', () => {
			clearTimeout(handle);
		//	this.dragging = false;
		});
	}

}
